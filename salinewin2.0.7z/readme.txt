salinewin.exe by pankoza
This is a Malware
This is very dangerous for the non-safety version
The non-safety version will corrupt the MBR and make the PC unusable. Run it only on a virtual machine
I'm not responsible for any damages
Credits to GetMBR for the Hue Function and credits to EthernalVortex for PRGBQUAD